let btn = document.querySelector('.btn');

btn.addEventListener('click', function(){
    Swal.fire('Привіт Давид!');
    // alert("привіт");
});